
# UI folder

Open `UI/html/index.html` in a browser to view the prototype.
All pages use localStorage for demo data in the browser. The `php/api.php` is a simple example that connects to the SQLite database in `/sql/plantcare.db`.
